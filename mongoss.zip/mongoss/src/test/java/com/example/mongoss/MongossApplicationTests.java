package com.example.mongoss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongossApplicationTests {

	@Test
	void contextLoads() {
	}

}
