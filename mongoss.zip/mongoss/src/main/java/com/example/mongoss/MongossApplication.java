package com.example.mongoss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongossApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongossApplication.class, args);
	}

}
